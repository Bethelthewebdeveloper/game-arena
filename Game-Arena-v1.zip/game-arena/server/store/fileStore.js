const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, '..', '..', 'data', 'arena-db.json');

function emptyDb() {
  return {
    users: [],
    sessions: [],
    resetTokens: [],
    activities: [],
    scores: [],
    userAchievements: []
  };
}

function load() {
  try {
    if (!fs.existsSync(FILE)) return emptyDb();
    const raw = fs.readFileSync(FILE, 'utf8');
    const data = JSON.parse(raw);
    return Object.assign(emptyDb(), data);
  } catch (e) {
    return emptyDb();
  }
}

function save(db) {
  const dir = path.dirname(FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(db, null, 2));
}

function nextId(prefix) {
  return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

module.exports = { load, save, nextId, FILE };
