const state = {
  isConnected: false,
  state: 'disconnected',
  dbName: process.env.MONGODB_DB_NAME || 'Game-Arena',
  mode: 'file'
};

async function connectDatabase() {
  const uri = String(process.env.MONGODB_URI || '').trim();
  if (!uri) {
    const err = new Error('MONGODB_URI is missing. Using local file database in data/arena-db.json');
    err.code = 'MISSING_URI';
    throw err;
  }
  const mongoose = require('mongoose');
  mongoose.set('strictQuery', true);
  await mongoose.connect(uri, { dbName: state.dbName });
  state.isConnected = true;
  state.state = 'connected';
  state.mode = 'mongo';
}

function getConnectionState() {
  return { ...state };
}

function setFileMode() {
  state.isConnected = false;
  state.state = 'file';
  state.mode = 'file';
}

module.exports = { connectDatabase, getConnectionState, setFileMode };
