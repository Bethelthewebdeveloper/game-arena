# Game Arena

Web gaming platform. One account, shared XP / levels / coins / streaks / achievements / leaderboards. Individual games plug in later.

The existing Riddle Game is **not** included in this project.

## Setup

```bash
cd game-arena
copy .env.example .env   # Windows
# or: cp .env.example .env
```

Edit `.env`:

- `SESSION_SECRET` — long random string
- `MONGODB_URI` — optional. If empty, a real local file database is used: `data/arena-db.json`
- `APP_PUBLIC_URL` — `http://127.0.0.1:8080` for local reset links

```bash
npm install
npm start
```

Open:

- Landing: http://127.0.0.1:8080/
- Sign up: http://127.0.0.1:8080/signup.html
- App: http://127.0.0.1:8080/app.html

On Windows PowerShell, if `npm start` is blocked, use `npm.cmd start`.

## Password reset

Email is not connected. Use **Forgot password**, then open the link printed in the server terminal (development only).
