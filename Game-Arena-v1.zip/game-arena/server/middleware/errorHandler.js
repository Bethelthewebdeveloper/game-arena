function notFound(req, res, next) {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ success: false, error: 'Not found', code: 'NOT_FOUND' });
  }
  next();
}

function errorHandler(err, req, res, next) {
  const status = err.status || 500;
  if (status >= 500) console.error('[api]', err);
  res.status(status).json({
    success: false,
    error: status >= 500 ? 'Server error' : err.message || 'Request failed',
    code: err.code || 'ERROR'
  });
}

module.exports = { notFound, errorHandler };
