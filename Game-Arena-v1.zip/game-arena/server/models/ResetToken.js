const mongoose = require('mongoose');

const ResetSchema = new mongoose.Schema({
  tokenHash: { type: String, required: true, unique: true },
  userId: { type: String, required: true },
  expiresAt: { type: Date, required: true }
});

module.exports = mongoose.models.ArenaReset || mongoose.model('ArenaReset', ResetSchema);
