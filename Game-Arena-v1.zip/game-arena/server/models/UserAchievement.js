const mongoose = require('mongoose');

const UASchema = new mongoose.Schema({
  userId: { type: String, required: true, index: true },
  achievementId: { type: String, required: true },
  unlockedAt: { type: Date, default: Date.now }
});
UASchema.index({ userId: 1, achievementId: 1 }, { unique: true });

module.exports = mongoose.models.ArenaUserAchievement || mongoose.model('ArenaUserAchievement', UASchema);
