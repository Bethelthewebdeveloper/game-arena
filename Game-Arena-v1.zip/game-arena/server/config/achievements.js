module.exports = [
  { id: 'first_game', name: 'First Game', emoji: '🎮', description: 'Finish your first game on Game Arena.', check: (s) => s.gamesPlayed >= 1 },
  { id: 'play_10', name: 'Play 10 Games', emoji: '🎮', description: 'Finish 10 games.', check: (s) => s.gamesPlayed >= 10 },
  { id: 'first_win', name: 'First Victory', emoji: '🏆', description: 'Win a game.', check: (s) => s.wins >= 1 },
  { id: 'streak_3', name: '3-Day Streak', emoji: '🔥', description: 'Play on 3 days in a row.', check: (s) => s.currentStreak >= 3 },
  { id: 'streak_7', name: '7-Day Streak', emoji: '🔥', description: 'Play on 7 days in a row.', check: (s) => s.currentStreak >= 7 },
  { id: 'level_10', name: 'Level 10', emoji: '⭐', description: 'Reach level 10.', check: (s) => s.level >= 10 },
  { id: 'high_score', name: 'High Score', emoji: '🎯', description: 'Post a personal-best score of 500 or more.', check: (s) => s.bestScore >= 500 }
];
