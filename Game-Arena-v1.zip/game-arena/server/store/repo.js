const { getConnectionState } = require('../config/database');
const file = require('./fileStore');
const { levelFromXp } = require('../config/progression');

function useMongo() {
  return getConnectionState().mode === 'mongo' && getConnectionState().isConnected;
}

function publicUser(u) {
  if (!u) return null;
  const prog = levelFromXp(u.xp || 0);
  return {
    id: String(u.id || u._id),
    email: u.email,
    username: u.username,
    displayName: u.displayName || u.username,
    avatar: u.avatar || '🦊',
    status: u.status || 'active',
    xp: prog.xp,
    level: prog.level,
    xpIntoLevel: prog.xpIntoLevel,
    xpForNext: prog.xpForNext,
    xpToNext: prog.xpToNext,
    coins: u.coins || 0,
    gamesPlayed: u.gamesPlayed || 0,
    wins: u.wins || 0,
    bestScore: u.bestScore || 0,
    currentStreak: u.currentStreak || 0,
    longestStreak: u.longestStreak || 0,
    lastActivityDate: u.lastActivityDate || null,
    favoriteGameIds: u.favoriteGameIds || [],
    plan: u.plan === 'pro' && u.proUntil && new Date(u.proUntil) > new Date() ? 'pro' : 'free',
    proUntil: u.proUntil || null,
    settings: u.settings || {
      notifications: true,
      appearance: 'dark',
      privacyPublicProfile: true
    },
    createdAt: u.createdAt
  };
}

async function createUser(doc) {
  if (useMongo()) {
    const User = require('../models/User');
    const created = await User.create(doc);
    return created.toObject();
  }
  const db = file.load();
  const row = Object.assign(
    {
      id: file.nextId('usr'),
      displayName: doc.username,
      avatar: '🦊',
      status: 'active',
      role: 'player',
      xp: 0,
      level: 1,
      coins: 0,
      gamesPlayed: 0,
      wins: 0,
      bestScore: 0,
      currentStreak: 0,
      longestStreak: 0,
      lastActivityDate: null,
      favoriteGameIds: [],
      plan: 'free',
      proUntil: null,
      settings: { notifications: true, appearance: 'dark', privacyPublicProfile: true },
      createdAt: new Date().toISOString()
    },
    doc
  );
  db.users.push(row);
  file.save(db);
  return row;
}

async function findUserByEmail(email) {
  const key = String(email || '').trim().toLowerCase();
  if (useMongo()) {
    const User = require('../models/User');
    return User.findOne({ email: key }).select('+passwordHash +passwordSalt').lean();
  }
  const db = file.load();
  return db.users.find((u) => u.email === key) || null;
}

async function findUserByUsername(username) {
  const key = String(username || '').trim().toLowerCase();
  if (useMongo()) {
    const User = require('../models/User');
    return User.findOne({ username: key }).select('+passwordHash +passwordSalt').lean();
  }
  const db = file.load();
  return db.users.find((u) => u.username === key) || null;
}

async function findUserById(id) {
  if (useMongo()) {
    const User = require('../models/User');
    return User.findById(id).lean();
  }
  const db = file.load();
  return db.users.find((u) => u.id === id) || null;
}

async function saveUser(user) {
  const prog = levelFromXp(user.xp || 0);
  user.level = prog.level;
  if (useMongo()) {
    const User = require('../models/User');
    const id = user._id || user.id;
    await User.updateOne({ _id: id }, { $set: user });
    return findUserById(id);
  }
  const db = file.load();
  const i = db.users.findIndex((u) => u.id === user.id);
  if (i >= 0) db.users[i] = user;
  file.save(db);
  return user;
}

async function deleteUser(id) {
  if (useMongo()) {
    const User = require('../models/User');
    const Session = require('../models/Session');
    const Score = require('../models/Score');
    const UA = require('../models/UserAchievement');
    await Promise.all([
      User.deleteOne({ _id: id }),
      Session.deleteMany({ userId: String(id) }),
      Score.deleteMany({ userId: String(id) }),
      UA.deleteMany({ userId: String(id) })
    ]);
    return;
  }
  const db = file.load();
  db.users = db.users.filter((u) => u.id !== id);
  db.sessions = db.sessions.filter((s) => s.userId !== id);
  db.scores = db.scores.filter((s) => s.userId !== id);
  db.userAchievements = db.userAchievements.filter((s) => s.userId !== id);
  db.resetTokens = db.resetTokens.filter((s) => s.userId !== id);
  file.save(db);
}

async function addSession(tokenHash, userId, expiresAt) {
  if (useMongo()) {
    const Session = require('../models/Session');
    await Session.create({ tokenHash, userId: String(userId), expiresAt });
    return;
  }
  const db = file.load();
  db.sessions.push({ tokenHash, userId, expiresAt: new Date(expiresAt).toISOString() });
  file.save(db);
}

async function findSession(tokenHash) {
  if (useMongo()) {
    const Session = require('../models/Session');
    return Session.findOne({ tokenHash, expiresAt: { $gt: new Date() } }).lean();
  }
  const db = file.load();
  const now = Date.now();
  return (
    db.sessions.find((s) => s.tokenHash === tokenHash && new Date(s.expiresAt).getTime() > now) || null
  );
}

async function deleteSession(tokenHash) {
  if (useMongo()) {
    const Session = require('../models/Session');
    await Session.deleteOne({ tokenHash });
    return;
  }
  const db = file.load();
  db.sessions = db.sessions.filter((s) => s.tokenHash !== tokenHash);
  file.save(db);
}

async function addResetToken(tokenHash, userId, expiresAt) {
  if (useMongo()) {
    const Reset = require('../models/ResetToken');
    await Reset.create({ tokenHash, userId: String(userId), expiresAt });
    return;
  }
  const db = file.load();
  db.resetTokens.push({ tokenHash, userId, expiresAt: new Date(expiresAt).toISOString() });
  file.save(db);
}

async function findResetToken(tokenHash) {
  if (useMongo()) {
    const Reset = require('../models/ResetToken');
    return Reset.findOne({ tokenHash, expiresAt: { $gt: new Date() } }).lean();
  }
  const db = file.load();
  const now = Date.now();
  return (
    db.resetTokens.find((s) => s.tokenHash === tokenHash && new Date(s.expiresAt).getTime() > now) ||
    null
  );
}

async function deleteResetToken(tokenHash) {
  if (useMongo()) {
    const Reset = require('../models/ResetToken');
    await Reset.deleteOne({ tokenHash });
    return;
  }
  const db = file.load();
  db.resetTokens = db.resetTokens.filter((s) => s.tokenHash !== tokenHash);
  file.save(db);
}

async function addScore(row) {
  const rec = Object.assign({ createdAt: new Date().toISOString() }, row);
  if (useMongo()) {
    const Score = require('../models/Score');
    await Score.create(rec);
    return rec;
  }
  const db = file.load();
  rec.id = file.nextId('scr');
  db.scores.push(rec);
  file.save(db);
  return rec;
}

async function listScores(userId, limit) {
  if (useMongo()) {
    const Score = require('../models/Score');
    return Score.find({ userId: String(userId) }).sort({ createdAt: -1 }).limit(limit || 10).lean();
  }
  const db = file.load();
  return db.scores
    .filter((s) => s.userId === userId)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, limit || 10);
}

async function addAchievement(userId, achievementId) {
  if (useMongo()) {
    const UA = require('../models/UserAchievement');
    try {
      await UA.create({ userId: String(userId), achievementId, unlockedAt: new Date() });
      return true;
    } catch (e) {
      return false;
    }
  }
  const db = file.load();
  if (db.userAchievements.some((a) => a.userId === userId && a.achievementId === achievementId)) {
    return false;
  }
  db.userAchievements.push({
    userId,
    achievementId,
    unlockedAt: new Date().toISOString()
  });
  file.save(db);
  return true;
}

async function listAchievements(userId) {
  if (useMongo()) {
    const UA = require('../models/UserAchievement');
    return UA.find({ userId: String(userId) }).lean();
  }
  const db = file.load();
  return db.userAchievements.filter((a) => a.userId === userId);
}

async function leaderboard(period) {
  const now = Date.now();
  let since = 0;
  if (period === 'daily') since = now - 24 * 3600 * 1000;
  if (period === 'weekly') since = now - 7 * 24 * 3600 * 1000;

  if (useMongo()) {
    const User = require('../models/User');
    const Score = require('../models/Score');
    if (period === 'all' || !period) {
      const users = await User.find({ status: 'active' }).sort({ xp: -1, wins: -1 }).limit(50).lean();
      return users.map((u, i) => ({
        rank: i + 1,
        username: u.username,
        avatar: u.avatar,
        level: u.level,
        xp: u.xp,
        wins: u.wins,
        gamesPlayed: u.gamesPlayed
      }));
    }
    const scores = await Score.find({ createdAt: { $gte: new Date(since) } }).lean();
    const map = {};
    scores.forEach((s) => {
      map[s.userId] = map[s.userId] || { userId: s.userId, score: 0, wins: 0 };
      map[s.userId].score += s.score || 0;
      if (s.won) map[s.userId].wins += 1;
    });
    const rows = Object.values(map).sort((a, b) => b.score - a.score || b.wins - a.wins).slice(0, 50);
    const out = [];
    for (let i = 0; i < rows.length; i++) {
      const u = await findUserById(rows[i].userId);
      if (!u) continue;
      out.push({
        rank: out.length + 1,
        username: u.username,
        avatar: u.avatar,
        level: u.level,
        xp: rows[i].score,
        wins: rows[i].wins,
        gamesPlayed: u.gamesPlayed
      });
    }
    return out;
  }

  const db = file.load();
  if (period === 'all' || !period) {
    return db.users
      .filter((u) => u.status !== 'deleted')
      .sort((a, b) => (b.xp || 0) - (a.xp || 0) || (b.wins || 0) - (a.wins || 0))
      .slice(0, 50)
      .map((u, i) => ({
        rank: i + 1,
        username: u.username,
        avatar: u.avatar,
        level: u.level,
        xp: u.xp,
        wins: u.wins,
        gamesPlayed: u.gamesPlayed
      }));
  }
  const map = {};
  db.scores
    .filter((s) => new Date(s.createdAt).getTime() >= since)
    .forEach((s) => {
      map[s.userId] = map[s.userId] || { userId: s.userId, score: 0, wins: 0 };
      map[s.userId].score += s.score || 0;
      if (s.won) map[s.userId].wins += 1;
    });
  return Object.values(map)
    .sort((a, b) => b.score - a.score)
    .slice(0, 50)
    .map((row, i) => {
      const u = db.users.find((x) => x.id === row.userId);
      if (!u) return null;
      return {
        rank: i + 1,
        username: u.username,
        avatar: u.avatar,
        level: u.level,
        xp: row.score,
        wins: row.wins,
        gamesPlayed: u.gamesPlayed
      };
    })
    .filter(Boolean);
}

module.exports = {
  publicUser,
  createUser,
  findUserByEmail,
  findUserByUsername,
  findUserById,
  saveUser,
  deleteUser,
  addSession,
  findSession,
  deleteSession,
  addResetToken,
  findResetToken,
  deleteResetToken,
  addScore,
  listScores,
  addAchievement,
  listAchievements,
  leaderboard
};
