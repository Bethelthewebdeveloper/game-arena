/**
 * Game catalog — only mark a game playable when it is actually connected.
 */
module.exports = [
  {
    id: 'riddle',
    name: 'Riddle Challenge',
    emoji: '🧩',
    blurb: 'Solve riddles against the clock.',
    status: 'not_connected',
    label: 'Coming Soon / Not Connected Yet',
    playable: false
  },
  {
    id: 'reflex',
    name: 'Reflex Challenge',
    emoji: '🎯',
    blurb: 'Tap as soon as the signal appears.',
    status: 'coming_soon',
    label: 'Coming Soon',
    playable: false
  },
  {
    id: 'penalty',
    name: 'Penalty Shootout',
    emoji: '⚽',
    blurb: 'Take the shot. Beat the keeper.',
    status: 'coming_soon',
    label: 'Coming Soon',
    playable: false
  },
  {
    id: 'memory',
    name: 'Memory Challenge',
    emoji: '🧠',
    blurb: 'Match pairs and train your memory.',
    status: 'coming_soon',
    label: 'Coming Soon',
    playable: false
  }
];
