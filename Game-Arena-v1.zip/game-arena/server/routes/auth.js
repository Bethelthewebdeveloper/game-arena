const express = require('express');
const rateLimit = require('express-rate-limit');
const { hashPassword, verifyPassword, randomToken, sha256 } = require('../lib/crypto');
const repo = require('../store/repo');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 40,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many attempts. Try later.', code: 'RATE_LIMIT' }
});

function validEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email || '').toLowerCase());
}

function publicBase() {
  return String(process.env.APP_PUBLIC_URL || '').replace(/\/$/, '') || '';
}

router.post('/signup', limiter, async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const username = String(req.body.username || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!validEmail(email)) {
      return res.status(400).json({ success: false, error: 'Enter a valid email.', code: 'BAD_EMAIL' });
    }
    if (!/^[a-z0-9_]{3,20}$/.test(username)) {
      return res.status(400).json({
        success: false,
        error: 'Username must be 3–20 letters, numbers, or underscore.',
        code: 'BAD_USERNAME'
      });
    }
    if (password.length < 8) {
      return res.status(400).json({ success: false, error: 'Password must be at least 8 characters.', code: 'WEAK_PASSWORD' });
    }
    if (await repo.findUserByEmail(email)) {
      return res.status(409).json({ success: false, error: 'That email is already registered.', code: 'EMAIL_TAKEN' });
    }
    if (await repo.findUserByUsername(username)) {
      return res.status(409).json({ success: false, error: 'That username is taken.', code: 'USERNAME_TAKEN' });
    }
    const pw = hashPassword(password);
    const user = await repo.createUser({
      email,
      username,
      passwordHash: pw.hash,
      passwordSalt: pw.salt,
      displayName: username
    });
    const raw = randomToken(24);
    const expiresAt = new Date(Date.now() + 14 * 864e5);
    await repo.addSession(sha256(raw), user.id || String(user._id), expiresAt);
    res.status(201).json({
      success: true,
      token: raw,
      expiresAt,
      user: repo.publicUser(user)
    });
  } catch (err) {
    next(err);
  }
});

router.post('/login', limiter, async (req, res, next) => {
  try {
    const login = String(req.body.email || req.body.username || req.body.login || '')
      .trim()
      .toLowerCase();
    const password = String(req.body.password || '');
    if (!login || !password) {
      return res.status(400).json({ success: false, error: 'Email/username and password required.', code: 'MISSING' });
    }
    let user = login.includes('@') ? await repo.findUserByEmail(login) : await repo.findUserByUsername(login);
    if (!user && login.includes('@')) user = await repo.findUserByUsername(login);
    if (!user || user.status === 'deleted') {
      return res.status(401).json({ success: false, error: 'Wrong email or password.', code: 'DENIED' });
    }
    if (!verifyPassword(password, user.passwordSalt, user.passwordHash)) {
      return res.status(401).json({ success: false, error: 'Wrong email or password.', code: 'DENIED' });
    }
    const raw = randomToken(24);
    const expiresAt = new Date(Date.now() + 14 * 864e5);
    await repo.addSession(sha256(raw), user.id || String(user._id), expiresAt);
    res.json({ success: true, token: raw, expiresAt, user: repo.publicUser(user) });
  } catch (err) {
    next(err);
  }
});

router.post('/logout', requireAuth, async (req, res, next) => {
  try {
    await repo.deleteSession(sha256(req.token));
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

router.get('/me', requireAuth, async (req, res) => {
  res.json({ success: true, user: req.user });
});

router.post('/forgot', limiter, async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    // Always generic — do not reveal whether the email exists.
    const generic = {
      success: true,
      message: 'If that email is registered, a reset link was created. Check the server log when email is not configured.'
    };
    if (!validEmail(email)) return res.json(generic);
    const user = await repo.findUserByEmail(email);
    if (!user) return res.json(generic);
    const raw = randomToken(24);
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000);
    await repo.addResetToken(sha256(raw), user.id || String(user._id), expiresAt);
    const base = publicBase() || 'http://127.0.0.1:' + (process.env.PORT || 8080);
    const link = base + '/reset.html?token=' + raw;
    console.log('[auth] password reset link for', email, '→', link);
    if (!process.env.SMTP_URL) {
      return res.json({
        success: true,
        message: 'Email sending is not configured. Open the reset link printed in the server terminal.',
        developmentLink: process.env.NODE_ENV === 'production' ? undefined : link
      });
    }
    res.json(generic);
  } catch (err) {
    next(err);
  }
});

router.post('/reset', limiter, async (req, res, next) => {
  try {
    const token = String(req.body.token || '').trim();
    const password = String(req.body.password || '');
    if (!token || password.length < 8) {
      return res.status(400).json({ success: false, error: 'Valid token and a new password (8+ chars) required.', code: 'BAD_RESET' });
    }
    const row = await repo.findResetToken(sha256(token));
    if (!row) {
      return res.status(400).json({ success: false, error: 'Reset link is invalid or expired.', code: 'BAD_TOKEN' });
    }
    const user = await repo.findUserById(row.userId);
    if (!user) {
      return res.status(400).json({ success: false, error: 'Reset link is invalid or expired.', code: 'BAD_TOKEN' });
    }
    const pw = hashPassword(password);
    user.passwordHash = pw.hash;
    user.passwordSalt = pw.salt;
    await repo.saveUser(user);
    await repo.deleteResetToken(sha256(token));
    res.json({ success: true, message: 'Password updated. You can sign in now.' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
