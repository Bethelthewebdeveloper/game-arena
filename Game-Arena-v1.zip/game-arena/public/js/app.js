(function () {
  if (!ArenaAPI.token()) {
    location.href = '/login.html';
    return;
  }

  const view = document.getElementById('view');
  const side = document.getElementById('side');
  let cache = null;

  document.getElementById('btn-menu').onclick = function () {
    side.classList.toggle('open');
  };
  document.getElementById('btn-logout').onclick = async function () {
    await ArenaAPI.post('/api/auth/logout', {});
    ArenaAPI.setToken(null);
    location.href = '/';
  };

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function kpi(label, value) {
    return '<div class="card"><div class="muted">' + esc(label) + '</div><div class="kpi-val">' + esc(value) + '</div></div>';
  }

  async function loadDash() {
    const res = await ArenaAPI.get('/api/account/dashboard');
    if (!res.success) {
      if (res.code === 'UNAUTHENTICATED' || res.code === 'SESSION_EXPIRED') {
        ArenaAPI.setToken(null);
        location.href = '/login.html';
        return null;
      }
      view.innerHTML = '<p class="msg err">' + esc(res.error || 'Could not load dashboard') + '</p>';
      return null;
    }
    cache = res.data;
    return res.data;
  }

  function renderDashboard(d) {
    const u = d.user;
    view.innerHTML =
      '<h1>Welcome, ' + esc(u.displayName || u.username) + '</h1>' +
      '<div class="grid kpis">' +
      kpi('Level', u.level) +
      kpi('XP', u.xp + ' · ' + u.xpToNext + ' to next') +
      kpi('Coins', u.coins) +
      kpi('Streak', u.currentStreak + ' (best ' + u.longestStreak + ')') +
      '</div>' +
      '<h2>Daily challenge</h2><div class="card"><span class="tag">' + esc(d.dailyChallenge.message) + '</span></div>' +
      '<h2>Continue playing</h2><div class="card muted">No connected game yet. Continue Playing fills in after a game module posts a session.</div>' +
      '<h2>Featured games</h2><div class="grid cards">' +
      d.featured.map(function (g) {
        return '<article class="card"><div style="font-size:1.6rem">' + g.emoji + '</div><h3>' + esc(g.name) +
          '</h3><p class="muted">' + esc(g.blurb) + '</p><span class="tag">' + esc(g.label) + '</span></article>';
      }).join('') +
      '</div>' +
      '<h2>Recent scores</h2>' +
      (d.recentScores && d.recentScores.length
        ? '<div class="card"><table class="table"><tr><th>Game</th><th>Score</th><th>Result</th></tr>' +
          d.recentScores.map(function (s) {
            return '<tr><td>' + esc(s.gameId) + '</td><td>' + esc(s.score) + '</td><td>' + (s.won ? 'Win' : 'Played') + '</td></tr>';
          }).join('') + '</table></div>'
        : '<div class="card muted">No scores yet. Games have not been connected.</div>');
  }

  function renderGames(d) {
    view.innerHTML =
      '<h1>Game library</h1><p class="muted">Only connected games become playable. None are connected in this phase.</p><div class="grid cards">' +
      d.featured.map(function (g) {
        return '<article class="card"><div style="font-size:2rem">' + g.emoji + '</div><h3>' + esc(g.name) +
          '</h3><p class="muted">' + esc(g.blurb) + '</p><span class="tag">' + esc(g.label) +
          '</span><p><button class="btn ghost" disabled>Not available</button></p></article>';
      }).join('') + '</div>';
  }

  async function renderProfile() {
    const res = await ArenaAPI.get('/api/account/profile');
    if (!res.success) { view.innerHTML = '<p class="msg err">' + esc(res.error) + '</p>'; return; }
    const u = res.data.user;
    view.innerHTML =
      '<h1>Player profile</h1>' +
      '<div class="grid kpis">' +
      kpi('Avatar', u.avatar) +
      kpi('Username', u.username) +
      kpi('Level', u.level) +
      kpi('XP', u.xp) +
      kpi('Coins', u.coins) +
      kpi('Games played', u.gamesPlayed) +
      kpi('Wins', u.wins) +
      kpi('Best score', u.bestScore) +
      kpi('Current streak', u.currentStreak) +
      kpi('Longest streak', u.longestStreak) +
      '</div>' +
      '<h2>Achievements</h2><div class="grid cards">' +
      res.data.achievements.map(function (a) {
        return '<article class="card"><h3>' + a.emoji + ' ' + esc(a.name) + '</h3><p class="muted">' +
          esc(a.description) + '</p><span class="tag">' + (a.unlocked ? 'Unlocked' : 'Locked') + '</span></article>';
      }).join('') + '</div>' +
      '<h2>Favorite games</h2><div class="card muted">' +
      (u.favoriteGameIds && u.favoriteGameIds.length ? u.favoriteGameIds.join(', ') : 'None selected yet.') +
      '</div>';
  }

  async function renderLeaderboard() {
    view.innerHTML = '<h1>Leaderboards</h1><p class="muted">Overall board uses real XP. Per-game boards stay empty until those games post scores.</p><div id="lb"></div>';
    const box = document.getElementById('lb');
    async function paint(period) {
      const res = await ArenaAPI.get('/api/leaderboard?period=' + period);
      const rows = res.entries || [];
      box.innerHTML =
        '<p><button class="btn ghost" data-p="all">All time</button> <button class="btn ghost" data-p="weekly">Weekly</button> <button class="btn ghost" data-p="daily">Daily</button></p>' +
        (rows.length
          ? '<div class="card"><table class="table"><tr><th>#</th><th>Player</th><th>XP / pts</th><th>Wins</th></tr>' +
            rows.map(function (r) {
              return '<tr><td>' + r.rank + '</td><td>' + esc(r.avatar) + ' ' + esc(r.username) + '</td><td>' + r.xp + '</td><td>' + r.wins + '</td></tr>';
            }).join('') + '</table></div>'
          : '<div class="card muted">No data available yet.</div>');
      box.querySelectorAll('[data-p]').forEach(function (b) {
        b.onclick = function () { paint(b.getAttribute('data-p')); };
      });
    }
    paint('all');
  }

  function renderSettings(d) {
    const u = d.user;
    view.innerHTML =
      '<h1>Settings</h1>' +
      '<div class="card"><h3>Profile</h3><label>Display name</label><input id="s-name" value="' + esc(u.displayName) + '" /><label>Avatar emoji</label><input id="s-avatar" value="' + esc(u.avatar) + '" /><p class="msg" id="s-profile-msg"></p><button class="btn" id="s-save-profile">Save profile</button></div>' +
      '<div class="card"><h3>Account</h3><p class="muted">' + esc(u.email) + ' · @' + esc(u.username) + '</p></div>' +
      '<div class="card"><h3>Security</h3><label>Current password</label><input id="s-cur" type="password" /><label>New password</label><input id="s-new" type="password" /><p class="msg" id="s-pw-msg"></p><button class="btn" id="s-pw">Update password</button></div>' +
      '<div class="card"><h3>Notifications</h3><label><input id="s-note" type="checkbox" ' + (u.settings && u.settings.notifications ? 'checked' : '') + ' /> Product updates</label></div>' +
      '<div class="card"><h3>Appearance</h3><select id="s-theme"><option value="dark">Dark</option><option value="light">Light</option></select></div>' +
      '<div class="card"><h3>Subscription / Billing</h3><p>Plan: <strong>' + esc(u.plan) + '</strong></p><p class="muted">No payment provider is connected.</p><button class="btn warn" id="s-pro">Upgrade to Pro</button><p class="msg" id="s-pro-msg"></p></div>' +
      '<div class="card"><h3>Privacy</h3><label><input id="s-pub" type="checkbox" ' + (u.settings && u.settings.privacyPublicProfile ? 'checked' : '') + ' /> Public profile on leaderboards</label><p><button class="btn ghost" id="s-save-set">Save settings</button></p></div>' +
      '<div class="card"><h3>Help</h3><p class="muted">Game Arena is the shared platform. Individual games plug in later and send results to XP, coins, streaks, and leaderboards.</p></div>' +
      '<div class="card"><h3>Delete account</h3><p class="muted">Type your username to confirm. This cannot be undone.</p><input id="s-del" placeholder="' + esc(u.username) + '" /><p class="msg" id="s-del-msg"></p><button class="btn danger" id="s-delete">Delete account</button></div>';

    document.getElementById('s-theme').value = (u.settings && u.settings.appearance) || 'dark';
    document.getElementById('s-save-profile').onclick = async function () {
      const res = await ArenaAPI.patch('/api/account/profile', {
        displayName: document.getElementById('s-name').value,
        avatar: document.getElementById('s-avatar').value
      });
      const msg = document.getElementById('s-profile-msg');
      msg.className = res.success ? 'msg ok' : 'msg err';
      msg.textContent = res.success ? 'Saved' : (res.error || 'Could not save');
    };
    document.getElementById('s-pw').onclick = async function () {
      const res = await ArenaAPI.post('/api/account/password', {
        currentPassword: document.getElementById('s-cur').value,
        newPassword: document.getElementById('s-new').value
      });
      const msg = document.getElementById('s-pw-msg');
      msg.className = res.success ? 'msg ok' : 'msg err';
      msg.textContent = res.message || res.error || '';
    };
    document.getElementById('s-pro').onclick = async function () {
      const res = await ArenaAPI.post('/api/account/upgrade', {});
      document.getElementById('s-pro-msg').className = 'msg err';
      document.getElementById('s-pro-msg').textContent = res.error || 'Pro purchases are not currently available.';
    };
    document.getElementById('s-save-set').onclick = async function () {
      await ArenaAPI.patch('/api/account/settings', {
        notifications: document.getElementById('s-note').checked,
        appearance: document.getElementById('s-theme').value,
        privacyPublicProfile: document.getElementById('s-pub').checked
      });
    };
    document.getElementById('s-delete').onclick = async function () {
      const res = await ArenaAPI.del('/api/account', { confirm: document.getElementById('s-del').value });
      if (!res.success) {
        document.getElementById('s-del-msg').className = 'msg err';
        document.getElementById('s-del-msg').textContent = res.error || 'Could not delete';
        return;
      }
      ArenaAPI.setToken(null);
      location.href = '/';
    };
  }

  async function show(name) {
    document.querySelectorAll('.side a[data-view]').forEach(function (a) {
      a.classList.toggle('active', a.getAttribute('data-view') === name);
    });
    const d = cache || await loadDash();
    if (!d) return;
    if (name === 'games') return renderGames(d);
    if (name === 'profile') return renderProfile();
    if (name === 'leaderboard') return renderLeaderboard();
    if (name === 'settings') return renderSettings(d);
    return renderDashboard(d);
  }

  side.addEventListener('click', function (e) {
    const a = e.target.closest('a[data-view]');
    if (!a) return;
    e.preventDefault();
    show(a.getAttribute('data-view'));
  });

  loadDash().then(function (d) {
    if (d) show((location.hash || '#dashboard').slice(1) || 'dashboard');
  });
})();
