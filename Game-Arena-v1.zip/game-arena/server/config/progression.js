/**
 * Shared progression config — every future game should use these helpers,
 * not invent its own XP curve or coin table.
 */

/** XP required to REACH a level (cumulative). Level 1 starts at 0. */
function xpForLevel(level) {
  const n = Math.max(1, Math.floor(Number(level) || 1));
  if (n <= 1) return 0;
  // 80 * (level-1)^2  — easy to change in one place
  return 80 * (n - 1) * (n - 1);
}

function levelFromXp(xp) {
  const total = Math.max(0, Math.floor(Number(xp) || 0));
  let level = 1;
  while (xpForLevel(level + 1) <= total && level < 99) level += 1;
  const current = xpForLevel(level);
  const next = xpForLevel(Math.min(99, level + 1));
  return {
    level,
    xp: total,
    xpIntoLevel: total - current,
    xpForNext: Math.max(0, next - current),
    xpToNext: Math.max(0, next - total)
  };
}

const XP_REASONS = {
  GAME_COMPLETED: 25,
  GOOD_PERFORMANCE: 15,
  ACHIEVEMENT: 40,
  DAILY_ACTIVITY: 10,
  FIRST_WIN: 30
};

const COIN_REASONS = {
  GAME_COMPLETED: 8,
  GOOD_PERFORMANCE: 5,
  ACHIEVEMENT: 20,
  DAILY_ACTIVITY: 3
};

module.exports = {
  xpForLevel,
  levelFromXp,
  XP_REASONS,
  COIN_REASONS,
  MAX_LEVEL: 99
};
