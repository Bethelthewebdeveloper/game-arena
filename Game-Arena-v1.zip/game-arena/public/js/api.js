const ArenaAPI = (function () {
  const KEY = 'ga_token';
  function token() {
    try { return localStorage.getItem(KEY); } catch (e) { return null; }
  }
  function setToken(t) {
    try {
      if (t) localStorage.setItem(KEY, t);
      else localStorage.removeItem(KEY);
    } catch (e) {}
  }
  async function request(path, opts) {
    opts = opts || {};
    const headers = Object.assign({ Accept: 'application/json' }, opts.headers || {});
    if (opts.body && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
    if (token()) headers.Authorization = 'Bearer ' + token();
    let res;
    try {
      res = await fetch(path, {
        method: opts.method || 'GET',
        headers: headers,
        body: opts.body ? JSON.stringify(opts.body) : undefined
      });
    } catch (e) {
      return { success: false, error: 'Network error. Start the Game Arena server and use http://127.0.0.1:PORT' };
    }
    let data = {};
    try { data = await res.json(); } catch (e) {}
    if (!res.ok && data.success !== false) data.success = false;
    if (!data.error && !res.ok) data.error = 'Request failed';
    return data;
  }
  return {
    token: token,
    setToken: setToken,
    get: function (path) { return request(path); },
    post: function (path, body) { return request(path, { method: 'POST', body: body }); },
    patch: function (path, body) { return request(path, { method: 'PATCH', body: body }); },
    del: function (path, body) { return request(path, { method: 'DELETE', body: body }); }
  };
})();
