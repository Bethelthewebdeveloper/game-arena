const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const { connectDatabase, getConnectionState, setFileMode } = require('./config/database');
const { notFound, errorHandler } = require('./middleware/errorHandler');
const authRoutes = require('./routes/auth');
const accountRoutes = require('./routes/account');
const publicRoutes = require('./routes/public');

const app = express();
const PORT = parseInt(process.env.PORT, 10) || 8080;
const HOST = process.env.HOST || '0.0.0.0';

app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: true, credentials: false }));
app.use(express.json({ limit: '200kb' }));
app.use(morgan('tiny'));
app.use(
  rateLimit({
    windowMs: 60 * 1000,
    max: 180,
    standardHeaders: true,
    legacyHeaders: false
  })
);

app.use('/api/auth', authRoutes);
app.use('/api/account', accountRoutes);
app.use('/api', publicRoutes);

app.use(express.static(path.join(__dirname, '..', 'public')));

app.get('/', (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

app.use(notFound);
app.use(errorHandler);

async function start() {
  try {
    await connectDatabase();
    console.log('[boot] MongoDB connected');
  } catch (err) {
    setFileMode();
    console.warn('MongoDB not used:', err.message);
    console.warn('→ Local file database: data/arena-db.json');
  }
  app.listen(PORT, HOST, () => {
    const db = getConnectionState();
    console.log('Game Arena listening on http://127.0.0.1:' + PORT);
    console.log('Database mode:', db.mode);
    if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.includes('change-this')) {
      console.warn('[boot] Set SESSION_SECRET in .env for production.');
    }
  });
}

if (require.main === module) start();

module.exports = app;
