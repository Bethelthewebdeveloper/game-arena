const mongoose = require('mongoose');

const ScoreSchema = new mongoose.Schema({
  userId: { type: String, required: true, index: true },
  gameId: { type: String, required: true, index: true },
  score: { type: Number, required: true },
  won: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.models.ArenaScore || mongoose.model('ArenaScore', ScoreSchema);
