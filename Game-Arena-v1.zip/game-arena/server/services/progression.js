/**
 * Shared progression engine. Future games call recordResult() after a real match.
 * Do not copy this logic into each game module.
 */
const catalog = require('../config/achievements');
const { XP_REASONS, COIN_REASONS, levelFromXp } = require('../config/progression');
const repo = require('../store/repo');

function todayKey(tzDate) {
  const d = tzDate || new Date();
  return (
    d.getFullYear() +
    '-' +
    String(d.getMonth() + 1).padStart(2, '0') +
    '-' +
    String(d.getDate()).padStart(2, '0')
  );
}

function applyStreak(user) {
  const today = todayKey();
  const last = user.lastActivityDate;
  if (last === today) return user;
  const y = new Date();
  y.setDate(y.getDate() - 1);
  const yesterday = todayKey(y);
  if (last === yesterday) user.currentStreak = (user.currentStreak || 0) + 1;
  else user.currentStreak = 1;
  user.longestStreak = Math.max(user.longestStreak || 0, user.currentStreak);
  user.lastActivityDate = today;
  return user;
}

async function unlockDue(user) {
  const unlocked = await repo.listAchievements(user.id || user._id);
  const have = new Set(unlocked.map((a) => a.achievementId));
  const stats = {
    gamesPlayed: user.gamesPlayed || 0,
    wins: user.wins || 0,
    currentStreak: user.currentStreak || 0,
    level: levelFromXp(user.xp || 0).level,
    bestScore: user.bestScore || 0
  };
  const fresh = [];
  for (const item of catalog) {
    if (have.has(item.id)) continue;
    if (item.check(stats)) {
      const added = await repo.addAchievement(user.id || String(user._id), item.id);
      if (added) {
        user.xp = (user.xp || 0) + XP_REASONS.ACHIEVEMENT;
        user.coins = (user.coins || 0) + COIN_REASONS.ACHIEVEMENT;
        fresh.push(item.id);
      }
    }
  }
  return fresh;
}

/**
 * @param {object} input
 * @param {string} input.userId
 * @param {string} input.gameId
 * @param {number} input.score
 * @param {boolean} input.won
 * @param {boolean} input.completed
 * @param {boolean} input.goodPerformance
 */
async function recordResult(input) {
  const user = await repo.findUserById(input.userId);
  if (!user) {
    const err = new Error('User not found');
    err.status = 404;
    throw err;
  }
  applyStreak(user);
  let xpGain = 0;
  let coinGain = 0;
  if (input.completed) {
    user.gamesPlayed = (user.gamesPlayed || 0) + 1;
    xpGain += XP_REASONS.GAME_COMPLETED;
    coinGain += COIN_REASONS.GAME_COMPLETED;
  }
  if (input.won) {
    user.wins = (user.wins || 0) + 1;
    xpGain += XP_REASONS.FIRST_WIN;
  }
  if (input.goodPerformance) {
    xpGain += XP_REASONS.GOOD_PERFORMANCE;
    coinGain += COIN_REASONS.GOOD_PERFORMANCE;
  }
  const score = Math.max(0, Math.floor(Number(input.score) || 0));
  if (score > (user.bestScore || 0)) user.bestScore = score;
  user.xp = (user.xp || 0) + xpGain;
  user.coins = (user.coins || 0) + coinGain;

  if (input.completed) {
    await repo.addScore({
      userId: user.id || String(user._id),
      gameId: input.gameId || 'unknown',
      score,
      won: !!input.won
    });
  }

  const newAchievements = await unlockDue(user);
  await repo.saveUser(user);
  return {
    user: repo.publicUser(user),
    xpGain,
    coinGain,
    newAchievements
  };
}

async function touchDaily(userId) {
  const user = await repo.findUserById(userId);
  if (!user) return null;
  const before = user.lastActivityDate;
  applyStreak(user);
  if (before !== user.lastActivityDate) {
    user.xp = (user.xp || 0) + XP_REASONS.DAILY_ACTIVITY;
    user.coins = (user.coins || 0) + COIN_REASONS.DAILY_ACTIVITY;
  }
  await unlockDue(user);
  await repo.saveUser(user);
  return repo.publicUser(user);
}

module.exports = { recordResult, touchDaily, applyStreak, todayKey };
