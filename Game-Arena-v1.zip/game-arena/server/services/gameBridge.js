/**
 * How a future game module should talk to Game Arena.
 *
 * After a real match ends, the game server (not the browser alone) should call:
 *
 *   const progression = require('../services/progression');
 *   await progression.recordResult({
 *     userId,
 *     gameId: 'riddle',     // must match server/config/games.js id
 *     score: 850,
 *     won: true,
 *     completed: true,
 *     goodPerformance: score >= 700
 *   });
 *
 * Then:
 *   1. Mark the game playable in server/config/games.js (playable: true, status: 'live')
 *   2. Add a route under /games/<id> that serves that game
 *   3. Authenticate with the same Game Arena session token
 *
 * Do not duplicate XP, coins, streaks, achievements, or leaderboards inside the game.
 */
module.exports = {};
