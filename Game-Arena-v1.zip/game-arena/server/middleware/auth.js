const { sha256 } = require('../lib/crypto');
const repo = require('../store/repo');

function getBearer(req) {
  const h = req.headers.authorization || '';
  if (h.startsWith('Bearer ')) return h.slice(7);
  return null;
}

async function requireAuth(req, res, next) {
  try {
    const token = getBearer(req);
    if (!token) {
      return res.status(401).json({ success: false, error: 'Not signed in', code: 'UNAUTHENTICATED' });
    }
    const session = await repo.findSession(sha256(token));
    if (!session) {
      return res.status(401).json({ success: false, error: 'Session expired', code: 'SESSION_EXPIRED' });
    }
    const user = await repo.findUserById(session.userId);
    if (!user || user.status === 'deleted') {
      return res.status(401).json({ success: false, error: 'Account not found', code: 'USER_INVALID' });
    }
    req.token = token;
    req.userDoc = user;
    req.user = repo.publicUser(user);
    next();
  } catch (err) {
    next(err);
  }
}

module.exports = { requireAuth, getBearer };
