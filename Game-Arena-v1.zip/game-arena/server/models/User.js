const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema(
  {
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    username: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true, select: false },
    passwordSalt: { type: String, required: true, select: false },
    displayName: { type: String, default: '' },
    avatar: { type: String, default: '🦊' },
    status: { type: String, default: 'active' },
    role: { type: String, default: 'player' },
    xp: { type: Number, default: 0 },
    level: { type: Number, default: 1 },
    coins: { type: Number, default: 0 },
    gamesPlayed: { type: Number, default: 0 },
    wins: { type: Number, default: 0 },
    bestScore: { type: Number, default: 0 },
    currentStreak: { type: Number, default: 0 },
    longestStreak: { type: Number, default: 0 },
    lastActivityDate: { type: String, default: null },
    favoriteGameIds: { type: [String], default: [] },
    plan: { type: String, default: 'free' },
    proUntil: { type: Date, default: null },
    settings: {
      notifications: { type: Boolean, default: true },
      appearance: { type: String, default: 'dark' },
      privacyPublicProfile: { type: Boolean, default: true }
    }
  },
  { timestamps: true }
);

module.exports = mongoose.models.ArenaUser || mongoose.model('ArenaUser', UserSchema);
