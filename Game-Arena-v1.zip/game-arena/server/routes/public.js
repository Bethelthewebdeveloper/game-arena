const express = require('express');
const games = require('../config/games');
const plans = require('../config/plans');
const catalog = require('../config/achievements');
const { xpForLevel } = require('../config/progression');
const repo = require('../store/repo');
const { getConnectionState } = require('../config/database');

const router = express.Router();

router.get('/games', (req, res) => {
  res.json({ success: true, games });
});

router.get('/plans', (req, res) => {
  res.json({ success: true, plans, paymentIntegration: 'NOT_IMPLEMENTED' });
});

router.get('/achievements/catalog', (req, res) => {
  res.json({
    success: true,
    achievements: catalog.map((a) => ({
      id: a.id,
      name: a.name,
      emoji: a.emoji,
      description: a.description
    }))
  });
});

router.get('/levels', (req, res) => {
  const table = [];
  for (let i = 1; i <= 15; i++) table.push({ level: i, xpRequired: xpForLevel(i) });
  res.json({ success: true, table, note: 'Change server/config/progression.js to adjust the curve.' });
});

router.get('/leaderboard', async (req, res, next) => {
  try {
    const period = String(req.query.period || 'all');
    const gameId = String(req.query.gameId || 'overall');
    if (gameId !== 'overall') {
      return res.json({
        success: true,
        period,
        gameId,
        entries: [],
        message: 'Per-game leaderboards appear after that game is connected and posts real scores.'
      });
    }
    const entries = await repo.leaderboard(period === 'daily' || period === 'weekly' ? period : 'all');
    res.json({
      success: true,
      period: period === 'daily' || period === 'weekly' ? period : 'all',
      gameId: 'overall',
      entries
    });
  } catch (err) {
    next(err);
  }
});

router.get('/health', (req, res) => {
  const db = getConnectionState();
  res.json({
    success: true,
    service: 'game-arena',
    db: db.mode,
    state: db.state
  });
});

module.exports = router;
