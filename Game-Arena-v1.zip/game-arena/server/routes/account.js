const express = require('express');
const { requireAuth } = require('../middleware/auth');
const { verifyPassword, hashPassword } = require('../lib/crypto');
const repo = require('../store/repo');
const catalog = require('../config/achievements');
const games = require('../config/games');
const plans = require('../config/plans');
const progression = require('../services/progression');

const router = express.Router();
router.use(requireAuth);

router.get('/dashboard', async (req, res, next) => {
  try {
    await progression.touchDaily(req.user.id);
    const user = repo.publicUser(await repo.findUserById(req.user.id));
    const scores = await repo.listScores(req.user.id, 8);
    const unlocked = await repo.listAchievements(req.user.id);
    res.json({
      success: true,
      data: {
        user,
        featured: games,
        recentScores: scores,
        recentGames: scores.map((s) => s.gameId),
        continuePlaying: [],
        dailyChallenge: {
          available: false,
          message: 'No daily challenge is live until a game is connected.'
        },
        achievementsUnlocked: unlocked.length,
        plans
      }
    });
  } catch (err) {
    next(err);
  }
});

router.get('/profile', async (req, res, next) => {
  try {
    const unlocked = await repo.listAchievements(req.user.id);
    const have = new Set(unlocked.map((a) => a.achievementId));
    res.json({
      success: true,
      data: {
        user: req.user,
        achievements: catalog.map((a) => ({
          id: a.id,
          name: a.name,
          emoji: a.emoji,
          description: a.description,
          unlocked: have.has(a.id),
          unlockedAt: (unlocked.find((u) => u.achievementId === a.id) || {}).unlockedAt || null
        }))
      }
    });
  } catch (err) {
    next(err);
  }
});

router.patch('/profile', async (req, res, next) => {
  try {
    const user = await repo.findUserById(req.user.id);
    if (req.body.displayName) user.displayName = String(req.body.displayName).slice(0, 32);
    if (req.body.avatar) user.avatar = String(req.body.avatar).slice(0, 8);
    if (Array.isArray(req.body.favoriteGameIds)) {
      user.favoriteGameIds = req.body.favoriteGameIds.map(String).slice(0, 8);
    }
    await repo.saveUser(user);
    res.json({ success: true, user: repo.publicUser(user) });
  } catch (err) {
    next(err);
  }
});

router.patch('/settings', async (req, res, next) => {
  try {
    const user = await repo.findUserById(req.user.id);
    user.settings = user.settings || {};
    if (typeof req.body.notifications === 'boolean') user.settings.notifications = req.body.notifications;
    if (req.body.appearance === 'dark' || req.body.appearance === 'light') {
      user.settings.appearance = req.body.appearance;
    }
    if (typeof req.body.privacyPublicProfile === 'boolean') {
      user.settings.privacyPublicProfile = req.body.privacyPublicProfile;
    }
    await repo.saveUser(user);
    res.json({ success: true, user: repo.publicUser(user) });
  } catch (err) {
    next(err);
  }
});

router.post('/password', async (req, res, next) => {
  try {
    const user = await repo.findUserByEmail(req.user.email);
    const current = String(req.body.currentPassword || '');
    const nextPw = String(req.body.newPassword || '');
    if (!verifyPassword(current, user.passwordSalt, user.passwordHash)) {
      return res.status(401).json({ success: false, error: 'Current password is wrong.', code: 'DENIED' });
    }
    if (nextPw.length < 8) {
      return res.status(400).json({ success: false, error: 'New password must be at least 8 characters.', code: 'WEAK_PASSWORD' });
    }
    const pw = hashPassword(nextPw);
    user.passwordHash = pw.hash;
    user.passwordSalt = pw.salt;
    await repo.saveUser(user);
    res.json({ success: true, message: 'Password updated.' });
  } catch (err) {
    next(err);
  }
});

router.post('/upgrade', (req, res) => {
  res.json({
    success: false,
    code: 'PAYMENTS_NOT_CONNECTED',
    error: 'Pro purchases are not currently available.',
    paymentIntegration: 'NOT_IMPLEMENTED'
  });
});

router.delete('/', async (req, res, next) => {
  try {
    const confirm = String(req.body.confirm || '');
    if (confirm !== req.user.username) {
      return res.status(400).json({
        success: false,
        error: 'Type your username to confirm account deletion.',
        code: 'CONFIRM_REQUIRED'
      });
    }
    await repo.deleteUser(req.user.id);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
