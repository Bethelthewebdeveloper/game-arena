module.exports = {
  free: {
    id: 'free',
    name: 'Free',
    features: [
      'Access to free games (when they are connected)',
      'Basic profile',
      'Basic statistics',
      'Basic achievements',
      'Basic leaderboard'
    ]
  },
  pro: {
    id: 'pro',
    name: 'Pro',
    features: [
      'Additional game modes (when a game supports them)',
      'Advanced statistics',
      'Additional customization',
      'Exclusive challenges',
      'Premium features added later'
    ],
    note: 'Payment is not connected. Purchases are not available.'
  }
};
